<section class="single-post-meta clearfix">
    <div class="post-tags font-montserrat-reg clearfix">
		<?php the_tags( '','' ); ?>
    </div>
</section>