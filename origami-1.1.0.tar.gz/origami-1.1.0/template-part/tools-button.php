<div id="toc-button" class="tools-item" title="显示文章目录(点击显示或隐藏)">
    <i class="fa fa-indent fa-2x" aria-hidden="true"></i>
    <div class="toc"></div>
</div>
<div id="qrcode" class="tools-item" title="阅读转移"><div id="qrcode-img"></div><i class="fa fa-laptop fa-2x" aria-hidden="true"></i></div>
<div id="if-to-start"><span>已跳转到上次阅读的位置，从头阅读？</span><a href="javascript:no_to_start();">否</a><a href="javascript:to_start();">是</a></div>