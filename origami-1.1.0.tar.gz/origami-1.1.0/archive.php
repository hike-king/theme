<?php get_header(); ?>
<div id="main-content">
    <?php get_template_part('template-part/content'); ?>
</div>
<?php get_footer(); ?>